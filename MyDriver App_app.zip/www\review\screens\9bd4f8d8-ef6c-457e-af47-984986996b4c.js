var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-9bd4f8d8-ef6c-457e-af47-984986996b4c" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Pickup_Info_Standby_Screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/9bd4f8d8-ef6c-457e-af47-984986996b4c-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/9bd4f8d8-ef6c-457e-af47-984986996b4c-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/9bd4f8d8-ef6c-457e-af47-984986996b4c-1598269362005-ie8.css" /><![endif]-->\
      <div id="s-Image_Login" class="pie image firer click ie-background commentable non-processed"   datasizewidth="361px" datasizeheight="643px" dataX="0" dataY="0"   alt="image">\
          <img src="./images/8474a0ce-2c48-4c20-ae2e-df00e4289cad.png" />\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="213px" datasizeheight="37px" dataX="7" dataY="13" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="227px" datasizeheight="20px" dataX="23" dataY="30" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Update Pickup Requirements Info.</span></div></div></div></div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="346px" datasizeheight="72px" dataX="8" dataY="284" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0">Waiting for Updated <br />Shipment Details</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;