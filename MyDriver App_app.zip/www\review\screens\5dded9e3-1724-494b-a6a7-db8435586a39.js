var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-5dded9e3-1724-494b-a6a7-db8435586a39" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Reject_Reason_Screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/5dded9e3-1724-494b-a6a7-db8435586a39-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/5dded9e3-1724-494b-a6a7-db8435586a39-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/5dded9e3-1724-494b-a6a7-db8435586a39-1598269362005-ie8.css" /><![endif]-->\
      <div id="s-Bg_1" class="pie percentage label singleline firer click commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_1_0"></span></div></div></div></div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="154px" datasizeheight="23px" dataX="20" dataY="29" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Rejection Reason</span></div></div></div></div>\
      <div id="s-more-vertical_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="25"   alt="image" systemName="./images/4cc9d038-976c-44a6-ab37-82b8b7e1b7f3.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
      </div>\
      <div id="s-Button_pod" class="pie button singleline firer click commentable non-processed"   datasizewidth="345px" datasizeheight="49px" dataX="7" dataY="568" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_pod_0">OK</span></div></div></div></div>\
      <div id="s-Input_1" class="pie text firer ie-background commentable non-processed"  datasizewidth="298px" datasizeheight="51px" dataX="35" dataY="128" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Please Type the Reason:" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_2" class="pie text firer ie-background commentable non-processed"  datasizewidth="298px" datasizeheight="30px" dataX="35" dataY="178" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_3" class="pie text firer ie-background commentable non-processed"  datasizewidth="298px" datasizeheight="30px" dataX="31" dataY="207" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_4" class="pie text firer ie-background commentable non-processed"  datasizewidth="298px" datasizeheight="30px" dataX="35" dataY="236" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_5" class="pie text firer ie-background commentable non-processed"  datasizewidth="298px" datasizeheight="30px" dataX="35" dataY="265" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;