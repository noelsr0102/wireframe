var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-ae27051c-44d3-4c6c-bb3c-a8f87b04a1a2" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="pickuprequest_Screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ae27051c-44d3-4c6c-bb3c-a8f87b04a1a2-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/ae27051c-44d3-4c6c-bb3c-a8f87b04a1a2-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/ae27051c-44d3-4c6c-bb3c-a8f87b04a1a2-1598269362005-ie8.css" /><![endif]-->\
      <div id="s-Bg_1" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_1_0"></span></div></div></div></div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="96px" datasizeheight="23px" dataX="20" dataY="29" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Notification</span></div></div></div></div>\
      <div id="s-more-vertical_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="25"   alt="image" systemName="./images/4cc9d038-976c-44a6-ab37-82b8b7e1b7f3.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
      </div>\
      <div id="s-notification" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="29px" dataX="0" dataY="75" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-notification_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_locations" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="226px" datasizeheight="15px" dataX="47" dataY="82" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_0">You Have Receive a New Pickup Request</span></div></div></div></div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="16px" dataX="17" dataY="80"   alt="image">\
          <img src="./images/9c66ab68-2662-4cea-a667-9f8780a605e5.png" />\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="318px" datasizeheight="168px" dataX="17" dataY="294" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Consignee Name &nbsp; &nbsp;: &nbsp;Consolacion Mariano<br />Consignee Address: &nbsp;Cebu City , 1111<br />Mode of Transport : &nbsp; AIR<br />Shipment Catgeory : &nbsp;DRY GOODS<br />Quantity &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : 2 BXS.<br />CBM &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : 0.0056<br />Declared Value &nbsp; &nbsp; &nbsp; &nbsp;: 10,000.00<br />Package Description : ELECTRONIC PARTS<br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_12" class="pie label singleline firer ie-background commentable non-processed"   datasizewidth="222px" datasizeheight="30px" dataX="19" dataY="109" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_12_0">Pickup Request Information</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_4" class="shapewrapper shapewrapper-s-Line_4 non-processed"   datasizewidth="318px" datasizeheight="2px" dataX="17" dataY="182" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_4" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_4" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 318 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_5" class="shapewrapper shapewrapper-s-Line_5 non-processed"   datasizewidth="318px" datasizeheight="2px" dataX="17" dataY="290" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_5" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_5" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 318 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="318px" datasizeheight="132px" dataX="17" dataY="153" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Shipment # 53638 &nbsp; &nbsp; &nbsp;Dispatch # 76253</span><span id="rtr-s-Paragraph_1_1"><br /><br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Customer 101<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;175 Jericho St. Brgy 107 Tondo<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;1700<br /></span><span id="rtr-s-Paragraph_1_2">Pickup Date and Time </span><span id="rtr-s-Paragraph_1_3">: &nbsp; &nbsp; August 10, 2020 &nbsp;15:00<br /></span><span id="rtr-s-Paragraph_1_4">Site &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; :</span><span id="rtr-s-Paragraph_1_5"> &nbsp; &nbsp; &nbsp;PAXF Ireneville<br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_13" class="pie label singleline firer ie-background commentable non-processed"   datasizewidth="99px" datasizeheight="30px" dataX="17" dataY="184" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_13_0">Customer &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;:</span></div></div></div></div>\
      <div id="s-Text_14" class="pie label singleline firer ie-background commentable non-processed"   datasizewidth="99px" datasizeheight="30px" dataX="17" dataY="202" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_14_0">Pickup Address :</span></div></div></div></div>\
      <div id="s-Button_pod" class="pie button singleline firer click commentable non-processed"   datasizewidth="168px" datasizeheight="49px" dataX="7" dataY="568" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_pod_0">ACCEPT</span></div></div></div></div>\
      <div id="s-Button_pod_1" class="pie button singleline firer click commentable non-processed"   datasizewidth="174px" datasizeheight="49px" dataX="181" dataY="568" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_pod_1_0">REJECT</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_6" class="shapewrapper shapewrapper-s-Line_6 non-processed"   datasizewidth="318px" datasizeheight="2px" dataX="17" dataY="482" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_6" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_6" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 318 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;