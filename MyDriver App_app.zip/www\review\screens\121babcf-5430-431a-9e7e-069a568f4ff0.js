var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-121babcf-5430-431a-9e7e-069a568f4ff0" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Map2_screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/121babcf-5430-431a-9e7e-069a568f4ff0-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/121babcf-5430-431a-9e7e-069a568f4ff0-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/121babcf-5430-431a-9e7e-069a568f4ff0-1598269362005-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="359px" datasizeheight="565px" dataX="0" dataY="75"   alt="image">\
          <img src="./images/ba513f01-8568-4b21-84cf-8ac86ffbdc41.PNG" />\
      </div>\
      <div id="s-Bg_1" class="pie percentage label singleline firer click commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_1_0"></span></div></div></div></div>\
      <div id="s-more-vertical_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="25"   alt="image" systemName="./images/4cc9d038-976c-44a6-ab37-82b8b7e1b7f3.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
      </div>\
      <div id="s-Image_43" class="pie image firer click ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="25" dataY="26"   alt="image" systemName="./images/ad9722fa-5672-4872-b2e0-91a5db725c89.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z"/></svg>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;