var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-001886ad-e5d0-4268-a801-2876e86a7820" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="DeliverUpdate_Screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/001886ad-e5d0-4268-a801-2876e86a7820-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/001886ad-e5d0-4268-a801-2876e86a7820-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/001886ad-e5d0-4268-a801-2876e86a7820-1598269362005-ie8.css" /><![endif]-->\
      <div id="s-Bg_1" class="pie percentage label singleline firer click commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_1_0"></span></div></div></div></div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="139px" datasizeheight="23px" dataX="20" dataY="29" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Delivery Update</span></div></div></div></div>\
      <div id="s-more-vertical_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="25"   alt="image" systemName="./images/4cc9d038-976c-44a6-ab37-82b8b7e1b7f3.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="179px" datasizeheight="32px" dataX="-1" dataY="75" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="183px" datasizeheight="32px" dataX="177" dataY="75" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_deliver" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="60px" datasizeheight="23px" dataX="55" dataY="79" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_deliver_0">Deliver</span></div></div></div></div>\
      <div id="s-Text_pickup" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="58px" datasizeheight="23px" dataX="229" dataY="79" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_pickup_0">Pickup</span></div></div></div></div>\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="450px" dataX="0" dataY="109" >\
        <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="359px" datasizeheight="29px" dataX="1" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Rectangle_3_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Text_locations" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="65px" datasizeheight="16px" dataX="28" dataY="116" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_0">Location/s</span></div></div></div></div>\
        <div id="s-Text_locations_1" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="34px" datasizeheight="16px" dataX="101" dataY="115" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_1_0">1 &nbsp;/ &nbsp;5</span></div></div></div></div>\
        <div id="s-Image_121" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="1" dataY="1"   alt="image" systemName="./images/b2a0bb98-d46b-4d17-b478-74db274632c9.svg" overlay="#0F0F92">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>\
        </div>\
        <div id="s-Text_locations_2" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="137px" datasizeheight="15px" dataX="7" dataY="141" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_2_0">For Deliver </span><span id="rtr-s-Text_locations_2_1">5</span><span id="rtr-s-Text_locations_2_2"> Shipment/s</span></div></div></div></div>\
        <div id="s-Rectangle_4" class="pie rectangle firer commentable non-processed"   datasizewidth="359px" datasizeheight="22px" dataX="0" dataY="50" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Rectangle_4_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Text_locations_3" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="299px" datasizeheight="15px" dataX="7" dataY="162" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_3_0">Shipment # 54321 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Invoice # 098765</span></div></div></div></div>\
        <div id="s-Text_locations_4" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="85px" datasizeheight="14px" dataX="82" dataY="187" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_4_0">Customer Name 1</span></div></div></div></div>\
        <div id="s-Text_locations_5" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="228px" datasizeheight="14px" dataX="82" dataY="205" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_5_0">Customer Name 1 Address, Makati Metro Manila</span></div></div></div></div>\
        <div id="s-Text_locations_6" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="228px" datasizeheight="14px" dataX="82" dataY="222" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_6_0">Customer Name 1 Address, Makati Metro Manila</span></div></div></div></div>\
        <div id="s-Text_locations_7" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="56px" datasizeheight="14px" dataX="5" dataY="187" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_7_0">Customer</span></div></div></div></div>\
        <div id="s-Text_locations_8" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="48px" datasizeheight="14px" dataX="5" dataY="205" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_8_0">Address</span></div></div></div></div>\
        <div id="s-Image_122" class="pie image firer ie-background commentable non-processed"   datasizewidth="17px" datasizeheight="17px" dataX="64" dataY="93"   alt="image" systemName="./images/d9e652fe-abdd-4ece-b9db-8677f7708f0d.svg" overlay="#7D7D7D">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>\
        </div>\
        <div id="s-Image_76" class="pie image firer ie-background commentable non-processed"   datasizewidth="17px" datasizeheight="17px" dataX="64" dataY="78"   alt="image" systemName="./images/0d36e96b-5aab-4bb4-935e-ac71a765073c.svg" overlay="#7D7D7D">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>\
        </div>\
        <div id="s-Text_locations_9" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="131px" datasizeheight="14px" dataX="82" dataY="238" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_9_0">Customer Name 1 Zip Code</span></div></div></div></div>\
        <div id="s-Text_locations_10" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="41px" datasizeheight="13px" dataX="9" dataY="266" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_10_0">Loaded</span></div></div></div></div>\
\
          <div id="s-Input_check" class="pie checkbox firer commentable non-processed nonMobile" datasizewidth="13px" datasizeheight="13px" dataX="330" dataY="80" >\
            <input class="checkBoxInput" type="checkbox"   value="true"  checked="checked" tabindex="-1" />\
          </div>\
\
        <div id="s-directions" class="pie image firer click ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="325" dataY="108"   alt="image" systemName="./images/1b51cfc5-e1bf-491c-8692-be020d6d004b.svg" overlay="#0F0F92">\
            <svg preserveAspectRatio=\'none\' fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">\
                <path d="M21.71 11.29l-9-9c-.39-.39-1.02-.39-1.41 0l-9 9c-.39.39-.39 1.02 0 1.41l9 9c.39.39 1.02.39 1.41 0l9-9c.39-.38.39-1.01 0-1.41zM14 14.5V12h-4v3H8v-4c0-.55.45-1 1-1h5V7.5l3.5 3.5-3.5 3.5z"/>\
                <path d="M0 0h24v24H0z" fill="none"/>\
            </svg>\
        </div>\
        <div id="s-Rectangle_8" class="pie rectangle firer commentable non-processed"   datasizewidth="359px" datasizeheight="22px" dataX="0" dataY="318" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Rectangle_8_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Text_locations_19" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="296px" datasizeheight="15px" dataX="7" dataY="430" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_19_0">Shipment # 54329 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Invoice # 598765</span></div></div></div></div>\
        <div id="s-Text_locations_20" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="85px" datasizeheight="14px" dataX="82" dataY="455" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_20_0">Customer Name 8</span></div></div></div></div>\
        <div id="s-Text_locations_21" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="228px" datasizeheight="14px" dataX="82" dataY="473" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_21_0">Customer Name 8 Address, Makati Metro Manila</span></div></div></div></div>\
        <div id="s-Text_locations_22" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="228px" datasizeheight="14px" dataX="82" dataY="490" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_22_0">Customer Name 8 Address, Makati Metro Manila</span></div></div></div></div>\
        <div id="s-Text_locations_23" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="56px" datasizeheight="14px" dataX="5" dataY="455" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_23_0">Customer</span></div></div></div></div>\
        <div id="s-Text_locations_24" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="48px" datasizeheight="14px" dataX="5" dataY="473" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_24_0">Address</span></div></div></div></div>\
        <div id="s-Image_124" class="pie image firer ie-background commentable non-processed"   datasizewidth="17px" datasizeheight="17px" dataX="64" dataY="361"   alt="image" systemName="./images/d9e652fe-abdd-4ece-b9db-8677f7708f0d.svg" overlay="#7D7D7D">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>\
        </div>\
        <div id="s-Image_78" class="pie image firer ie-background commentable non-processed"   datasizewidth="17px" datasizeheight="17px" dataX="64" dataY="346"   alt="image" systemName="./images/0d36e96b-5aab-4bb4-935e-ac71a765073c.svg" overlay="#7D7D7D">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>\
        </div>\
        <div id="s-Text_locations_25" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="131px" datasizeheight="14px" dataX="82" dataY="506" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_25_0">Customer Name 8 Zip Code</span></div></div></div></div>\
        <div id="s-Text_locations_26" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="119px" datasizeheight="13px" dataX="8" dataY="534" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_26_0">Arrived in Warehouse</span></div></div></div></div>\
        <div id="shapewrapper-s-Line_3" class="shapewrapper shapewrapper-s-Line_3 non-processed"   datasizewidth="360px" datasizeheight="2px" dataX="0" dataY="448" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_3" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 360 1"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
\
          <div id="s-Input_check_2" class="pie checkbox firer commentable non-processed nonMobile" datasizewidth="13px" datasizeheight="13px" dataX="330" dataY="348" >\
            <input class="checkBoxInput" type="checkbox"   value="true"  checked="checked" tabindex="-1" />\
          </div>\
\
        <div id="s-directions_2" class="pie image firer click ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="325" dataY="376"   alt="image" systemName="./images/1b51cfc5-e1bf-491c-8692-be020d6d004b.svg" overlay="#0F0F92">\
            <svg preserveAspectRatio=\'none\' fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">\
                <path d="M21.71 11.29l-9-9c-.39-.39-1.02-.39-1.41 0l-9 9c-.39.39-.39 1.02 0 1.41l9 9c.39.39 1.02.39 1.41 0l9-9c.39-.38.39-1.01 0-1.41zM14 14.5V12h-4v3H8v-4c0-.55.45-1 1-1h5V7.5l3.5 3.5-3.5 3.5z"/>\
                <path d="M0 0h24v24H0z" fill="none"/>\
            </svg>\
        </div>\
        <div id="s-Rectangle_6" class="pie rectangle firer commentable non-processed"   datasizewidth="359px" datasizeheight="22px" dataX="0" dataY="184" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Rectangle_6_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Text_locations_11" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="306px" datasizeheight="15px" dataX="7" dataY="296" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_11_0">Shipment # 54350 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Invoice # 129876</span><span id="rtr-s-Text_locations_11_1">5</span></div></div></div></div>\
        <div id="s-Text_locations_12" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="85px" datasizeheight="14px" dataX="82" dataY="321" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_12_0">Customer Name 5</span></div></div></div></div>\
        <div id="s-Text_locations_13" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="228px" datasizeheight="14px" dataX="82" dataY="339" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_13_0">Customer Name 5 Address, Makati Metro Manila</span></div></div></div></div>\
        <div id="s-Text_locations_14" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="228px" datasizeheight="14px" dataX="82" dataY="356" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_14_0">Customer Name 5 Address, Makati Metro Manila</span></div></div></div></div>\
        <div id="s-Text_locations_15" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="56px" datasizeheight="14px" dataX="5" dataY="321" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_15_0">Customer</span></div></div></div></div>\
        <div id="s-Text_locations_16" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="48px" datasizeheight="14px" dataX="5" dataY="339" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_16_0">Address</span></div></div></div></div>\
        <div id="s-Image_123" class="pie image firer ie-background commentable non-processed"   datasizewidth="17px" datasizeheight="17px" dataX="64" dataY="227"   alt="image" systemName="./images/d9e652fe-abdd-4ece-b9db-8677f7708f0d.svg" overlay="#7D7D7D">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>\
        </div>\
        <div id="s-Image_77" class="pie image firer ie-background commentable non-processed"   datasizewidth="17px" datasizeheight="17px" dataX="64" dataY="212"   alt="image" systemName="./images/0d36e96b-5aab-4bb4-935e-ac71a765073c.svg" overlay="#7D7D7D">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>\
        </div>\
        <div id="s-Text_locations_17" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="131px" datasizeheight="14px" dataX="82" dataY="372" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_17_0">Customer Name 5 Zip Code</span></div></div></div></div>\
        <div id="s-Text_locations_18" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="52px" datasizeheight="13px" dataX="9" dataY="400" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_locations_18_0">Delivered</span></div></div></div></div>\
        <div id="shapewrapper-s-Line_2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="360px" datasizeheight="2px" dataX="0" dataY="314" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 360 1"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
        <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="360px" datasizeheight="2px" dataX="0" dataY="177" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 360 1"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
      </div>\
      <div id="s-Button_Update" class="pie button singleline firer commentable non-processed"   datasizewidth="112px" datasizeheight="30px" dataX="5" dataY="582" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_Update_0">UPDATE</span></div></div></div></div>\
      <div id="s-Button_pod" class="pie button singleline firer commentable non-processed"   datasizewidth="118px" datasizeheight="30px" dataX="126" dataY="582" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_pod_0">POD</span></div></div></div></div>\
      <div id="s-Button_pod_1" class="pie button singleline firer commentable non-processed"   datasizewidth="102px" datasizeheight="30px" dataX="253" dataY="582" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_pod_1_0">DEX</span></div></div></div></div>\
      <div id="s-Category_Checkins" class="pie radiobuttonlist firer commentable non-processed"    datasizewidth="237px" datasizeheight="165px" dataX="73" dataY="206"  tabindex="-1">\
        <div class="backgroundLayer"></div>\
        <div class="scroll">\
          <table class="collapse" style="height: 100%; width: 100%;" summary="">\
            <tbody>\
                <tr>\
                  <td>\
                      <input type="radio" name="s-Category_Checkins"   tabindex="-1" /><span class="option">Arrived in Consignee Warehouse</span>\
                  </td>\
                </tr>\
                <tr>\
                  <td>\
                      <input type="radio" name="s-Category_Checkins"   tabindex="-1" /><span class="option">Unloading of Cargoes</span>\
                  </td>\
                </tr>\
                <tr>\
                  <td>\
                      <input type="radio" name="s-Category_Checkins"   tabindex="-1" /><span class="option">Finished Unloading of Cargoes</span>\
                  </td>\
                </tr>\
            </tbody>\
          </table>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="pie rectangle firer commentable non-processed"   datasizewidth="237px" datasizeheight="40px" dataX="73" dataY="370" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_5_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="174" dataY="381" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Cancel</span></div></div></div></div>\
      <div id="s-Rectangle_7" class="pie rectangle firer commentable non-processed"   datasizewidth="237px" datasizeheight="40px" dataX="73" dataY="167" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_7_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="105px" datasizeheight="20px" dataX="134" dataY="177" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Check-in Types</span></div></div></div></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="20px" dataX="257" dataY="380" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0"> OK</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;