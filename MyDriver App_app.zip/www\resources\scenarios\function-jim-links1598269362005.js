(function(window, undefined) {

  var jimLinks = {
    "5baafd5b-4c4c-4b1f-84f9-909afe9ecb2d" : {
      "Image_Login" : [
        "9c2c4717-05b6-4fb8-b511-d10019deebe8"
      ]
    },
    "33526f3c-a43b-4c49-a3bf-4bd3cdaf837e" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Button_pod" : [
        "60d62d3b-a1fe-4b92-bd61-35d82b491c49"
      ],
      "Button_pod_1" : [
        "af44408f-9bcc-465b-9119-db19ee1ef7fa"
      ]
    },
    "eb71d8d5-bcbd-45dd-b413-324312dac3eb" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Button_pod" : [
        "33526f3c-a43b-4c49-a3bf-4bd3cdaf837e"
      ],
      "Button_pod_1" : [
        "af44408f-9bcc-465b-9119-db19ee1ef7fa"
      ],
      "Button_pod_2" : [
        "9bd4f8d8-ef6c-457e-af47-984986996b4c"
      ]
    },
    "6bda7741-17b7-45ce-81a0-3a0e542a0dab" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Image_43" : [
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070"
      ]
    },
    "5dded9e3-1724-494b-a6a7-db8435586a39" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Button_pod" : [
        "792f207f-a8e5-47d6-af24-04185330b0cb"
      ]
    },
    "7b4f713a-e953-4040-b6df-c5afade4bdda" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Button_pod" : [
        "b58f1d43-4a0a-4856-8a39-6165da4fdc1b"
      ],
      "Button_pod_1" : [
        "56124299-16ed-4403-8ec1-f238aa7c99ea"
      ]
    },
    "9bd4f8d8-ef6c-457e-af47-984986996b4c" : {
      "Image_Login" : [
        "ae27051c-44d3-4c6c-bb3c-a8f87b04a1a2"
      ]
    },
    "9e0b249d-a0e8-44f1-aff8-fddce9b3ab95" : {
      "Image_1" : [
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070"
      ]
    },
    "af44408f-9bcc-465b-9119-db19ee1ef7fa" : {
      "Rectangle_1" : [
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070"
      ],
      "Rectangle_2" : [
        "af44408f-9bcc-465b-9119-db19ee1ef7fa"
      ],
      "directions" : [
        "121babcf-5430-431a-9e7e-069a568f4ff0"
      ],
      "Button_pod" : [
        "eb71d8d5-bcbd-45dd-b413-324312dac3eb"
      ],
      "Button_pod_1" : [
        "22277bad-a603-4325-ab7a-980c11b93e81"
      ]
    },
    "681e9126-e3b0-400e-a8df-a016e721d862" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Button_pod" : [
        "b58f1d43-4a0a-4856-8a39-6165da4fdc1b"
      ],
      "Button_pod_1" : [
        "af44408f-9bcc-465b-9119-db19ee1ef7fa"
      ]
    },
    "ae27051c-44d3-4c6c-bb3c-a8f87b04a1a2" : {
      "Button_pod" : [
        "af44408f-9bcc-465b-9119-db19ee1ef7fa"
      ],
      "Button_pod_1" : [
        "5dded9e3-1724-494b-a6a7-db8435586a39"
      ]
    },
    "ebc29430-19f7-4647-886e-da20729b5ccd" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Rectangle_1" : [
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070"
      ],
      "Rectangle_2" : [
        "af44408f-9bcc-465b-9119-db19ee1ef7fa"
      ],
      "directions" : [
        "121babcf-5430-431a-9e7e-069a568f4ff0"
      ],
      "Button_pod" : [
        "eb71d8d5-bcbd-45dd-b413-324312dac3eb"
      ],
      "Button_pod_1" : [
        "22277bad-a603-4325-ab7a-980c11b93e81"
      ]
    },
    "a8b5f2d8-6b49-4328-8d62-afcc2297ba2c" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Rectangle_1" : [
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070"
      ],
      "Rectangle_2" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ]
    },
    "76b3ad9a-04d4-44e5-89dc-32f359fdad8a" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Button_pod" : [
        "56124299-16ed-4403-8ec1-f238aa7c99ea"
      ]
    },
    "0651cc37-5f92-474c-b213-96bd3a741be3" : {
      "Image_1" : [
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070",
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070"
      ]
    },
    "001886ad-e5d0-4268-a801-2876e86a7820" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "directions" : [
        "6bda7741-17b7-45ce-81a0-3a0e542a0dab"
      ],
      "directions_2" : [
        "6bda7741-17b7-45ce-81a0-3a0e542a0dab"
      ],
      "Text_3" : [
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070"
      ],
      "Text_5" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ]
    },
    "60d62d3b-a1fe-4b92-bd61-35d82b491c49" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Button_pod" : [
        "b58f1d43-4a0a-4856-8a39-6165da4fdc1b"
      ],
      "Button_pod_1" : [
        "af44408f-9bcc-465b-9119-db19ee1ef7fa"
      ]
    },
    "9c2c4717-05b6-4fb8-b511-d10019deebe8" : {
      "Image_Login" : [
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070"
      ]
    },
    "b58f1d43-4a0a-4856-8a39-6165da4fdc1b" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Button_pod" : [
        "a8b5f2d8-6b49-4328-8d62-afcc2297ba2c"
      ]
    },
    "32ca08f1-a3b5-489e-82d9-680d0d3ac070" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Rectangle_1" : [
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070"
      ],
      "Rectangle_2" : [
        "792f207f-a8e5-47d6-af24-04185330b0cb"
      ],
      "directions" : [
        "6bda7741-17b7-45ce-81a0-3a0e542a0dab"
      ],
      "directions_2" : [
        "6bda7741-17b7-45ce-81a0-3a0e542a0dab"
      ],
      "Button_Update" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Button_pod" : [
        "0651cc37-5f92-474c-b213-96bd3a741be3"
      ],
      "Button_pod_1" : [
        "9e0b249d-a0e8-44f1-aff8-fddce9b3ab95"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Image_Login" : [
        "5baafd5b-4c4c-4b1f-84f9-909afe9ecb2d"
      ]
    },
    "121babcf-5430-431a-9e7e-069a568f4ff0" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Image_43" : [
        "af44408f-9bcc-465b-9119-db19ee1ef7fa"
      ]
    },
    "792f207f-a8e5-47d6-af24-04185330b0cb" : {
      "Rectangle_1" : [
        "32ca08f1-a3b5-489e-82d9-680d0d3ac070"
      ],
      "Image_1" : [
        "ae27051c-44d3-4c6c-bb3c-a8f87b04a1a2"
      ]
    },
    "56124299-16ed-4403-8ec1-f238aa7c99ea" : {
      "Bg_1" : [
        "001886ad-e5d0-4268-a801-2876e86a7820"
      ],
      "Button_pod" : [
        "681e9126-e3b0-400e-a8df-a016e721d862"
      ],
      "Button_pod_1" : [
        "af44408f-9bcc-465b-9119-db19ee1ef7fa"
      ],
      "Button_pod_2" : [
        "9bd4f8d8-ef6c-457e-af47-984986996b4c"
      ]
    },
    "22277bad-a603-4325-ab7a-980c11b93e81" : {
      "Button_pod_1" : [
        "af44408f-9bcc-465b-9119-db19ee1ef7fa"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);