var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-9c2c4717-05b6-4fb8-b511-d10019deebe8" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="eDS_Screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/9c2c4717-05b6-4fb8-b511-d10019deebe8-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/9c2c4717-05b6-4fb8-b511-d10019deebe8-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/9c2c4717-05b6-4fb8-b511-d10019deebe8-1598269362005-ie8.css" /><![endif]-->\
      <div id="s-Image_Login" class="pie image firer click ie-background commentable non-processed"   datasizewidth="361px" datasizeheight="643px" dataX="2" dataY="0"   alt="image">\
          <img src="./images/4d074c5c-225e-42a6-9a09-1710db1750ab.png" />\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;