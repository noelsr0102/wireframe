var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-792f207f-a8e5-47d6-af24-04185330b0cb" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="PickupRequestStandby_Screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/792f207f-a8e5-47d6-af24-04185330b0cb-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/792f207f-a8e5-47d6-af24-04185330b0cb-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/792f207f-a8e5-47d6-af24-04185330b0cb-1598269362005-ie8.css" /><![endif]-->\
      <div id="s-Bg_1" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_1_0"></span></div></div></div></div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="137px" datasizeheight="23px" dataX="20" dataY="29" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Pickup Request</span></div></div></div></div>\
      <div id="s-more-vertical_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="25"   alt="image" systemName="./images/4cc9d038-976c-44a6-ab37-82b8b7e1b7f3.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle firer click commentable non-processed"   datasizewidth="179px" datasizeheight="32px" dataX="-1" dataY="75" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="183px" datasizeheight="32px" dataX="177" dataY="75" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_deliver" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="60px" datasizeheight="23px" dataX="55" dataY="79" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_deliver_0">Deliver</span></div></div></div></div>\
      <div id="s-Text_pickup" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="58px" datasizeheight="23px" dataX="229" dataY="79" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_pickup_0">Pickup</span></div></div></div></div>\
\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="360px" datasizeheight="542px" dataX="0" dataY="105"   alt="image">\
          <img src="./images/81e300c2-8cb9-4250-b9d8-537966988bf1.png" />\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="357px" datasizeheight="77px" dataX="2" dataY="105" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_3_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="72px" dataX="0" dataY="340" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_4_0">No Pickup Request Assign<br />To You</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;