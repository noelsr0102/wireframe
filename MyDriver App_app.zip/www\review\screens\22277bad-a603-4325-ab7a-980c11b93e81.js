var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-22277bad-a603-4325-ab7a-980c11b93e81" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="PUXUpdate_Screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/22277bad-a603-4325-ab7a-980c11b93e81-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/22277bad-a603-4325-ab7a-980c11b93e81-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/22277bad-a603-4325-ab7a-980c11b93e81-1598269362005-ie8.css" /><![endif]-->\
      <div id="s-Bg_1" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_1_0"></span></div></div></div></div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="40px" datasizeheight="24px" dataX="20" dataY="29" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">PUX</span></div></div></div></div>\
      <div id="s-more-vertical_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="25"   alt="image" systemName="./images/4cc9d038-976c-44a6-ab37-82b8b7e1b7f3.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="44px" dataX="1" dataY="76" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Search</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="20" dataY="86"   alt="image" systemName="./images/fdf2d949-243a-47c4-81b7-587220e2be22.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>\
      </div>\
      <div id="shapewrapper-s-Line_4" class="shapewrapper shapewrapper-s-Line_4 non-processed"   datasizewidth="360px" datasizeheight="2px" dataX="0" dataY="119" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_4" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_4" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 360 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_5" class="shapewrapper shapewrapper-s-Line_5 non-processed"   datasizewidth="360px" datasizeheight="2px" dataX="0" dataY="191" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_5" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_5" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 360 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Button_pod" class="pie button singleline firer commentable non-processed"   datasizewidth="168px" datasizeheight="49px" dataX="187" dataY="578" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_pod_0">SUBMIT</span></div></div></div></div>\
      <div id="s-Button_pod_1" class="pie button singleline firer click commentable non-processed"   datasizewidth="174px" datasizeheight="49px" dataX="7" dataY="578" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_pod_1_0">CANCEL</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_6" class="shapewrapper shapewrapper-s-Line_6 non-processed"   datasizewidth="360px" datasizeheight="2px" dataX="0" dataY="258" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_6" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_6" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 360 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_7" class="shapewrapper shapewrapper-s-Line_7 non-processed"   datasizewidth="360px" datasizeheight="2px" dataX="0" dataY="325" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_7" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_7" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 360 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="145px" datasizeheight="20px" dataX="25" dataY="155" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Shipper Not Available</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="123px" datasizeheight="20px" dataX="25" dataY="220" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Cancel By Shipper</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="30px" datasizeheight="20px" dataX="25" dataY="286" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">PUX</span></div></div></div></div>\
      <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="22px" datasizeheight="21px" dataX="286" dataY="155" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="11.0" cy="10.5" rx="11.0" ry="10.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="11.0" cy="10.5" rx="11.0" ry="10.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="shapert-clipping">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="22px" datasizeheight="21px" dataX="286" dataY="219" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_2)">\
                          <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="11.0" cy="10.5" rx="11.0" ry="10.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                          <ellipse cx="11.0" cy="10.5" rx="11.0" ry="10.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="shapert-clipping">\
              <div id="shapert-s-Ellipse_2" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_2_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_3" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="22px" datasizeheight="21px" dataX="286" dataY="285" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_3)">\
                          <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="11.0" cy="10.5" rx="11.0" ry="10.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                          <ellipse cx="11.0" cy="10.5" rx="11.0" ry="10.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="shapert-clipping">\
              <div id="shapert-s-Ellipse_3" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_3_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;