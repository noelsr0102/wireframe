var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1598269362005-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-56124299-16ed-4403-8ec1-f238aa7c99ea" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="2pickupUpdate_Screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/56124299-16ed-4403-8ec1-f238aa7c99ea-1598269362005.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/56124299-16ed-4403-8ec1-f238aa7c99ea-1598269362005-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/56124299-16ed-4403-8ec1-f238aa7c99ea-1598269362005-ie8.css" /><![endif]-->\
      <div id="s-Bg_1" class="pie percentage label singleline firer click commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_1_0"></span></div></div></div></div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="127px" datasizeheight="23px" dataX="20" dataY="29" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Pickup Update</span></div></div></div></div>\
      <div id="s-more-vertical_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="25"   alt="image" systemName="./images/4cc9d038-976c-44a6-ab37-82b8b7e1b7f3.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="343px" datasizeheight="227px" dataX="17" dataY="250" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Consignee Name &nbsp; &nbsp;: &nbsp;Consolacion Mariano<br />Consignee Address: &nbsp;Cebu City , 1111<br />Mode of Transport : &nbsp; SEA<br />Shipment Catgeory : &nbsp;DRY GOODS<br />Quantity &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : 2 BXS.<br />CBM &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : 0.0056<br />Declared Value &nbsp; &nbsp; &nbsp; &nbsp;: 10,000.00<br />Package Description : ELECTRONIC PARTS<br /><br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Freight &nbsp; &nbsp; &nbsp; : 650.00<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Insurance &nbsp;: 200.00<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span id="rtr-s-Paragraph_3_1">Total &nbsp; &nbsp; &nbsp; &nbsp;: &nbsp;850.00</span><span id="rtr-s-Paragraph_3_2"><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_12" class="pie label singleline firer ie-background commentable non-processed"   datasizewidth="222px" datasizeheight="30px" dataX="19" dataY="81" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_12_0">Pickup Request Information</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_4" class="shapewrapper shapewrapper-s-Line_4 non-processed"   datasizewidth="318px" datasizeheight="2px" dataX="17" dataY="138" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_4" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_4" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 318 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_5" class="shapewrapper shapewrapper-s-Line_5 non-processed"   datasizewidth="318px" datasizeheight="2px" dataX="17" dataY="246" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_5" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_5" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 318 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="318px" datasizeheight="132px" dataX="17" dataY="109" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Shipment # 53638 &nbsp; &nbsp; &nbsp;Dispatch # 76253</span><span id="rtr-s-Paragraph_1_1"><br /><br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Customer 101<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;175 Jericho St. Brgy 107 Tondo<br /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;1700<br /></span><span id="rtr-s-Paragraph_1_2">Pickup Date and Time </span><span id="rtr-s-Paragraph_1_3">: &nbsp; &nbsp; August 10, 2020 &nbsp;15:00<br /></span><span id="rtr-s-Paragraph_1_4">Site &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; :</span><span id="rtr-s-Paragraph_1_5"> &nbsp; &nbsp; &nbsp;PAXF Ireneville<br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_13" class="pie label singleline firer ie-background commentable non-processed"   datasizewidth="99px" datasizeheight="30px" dataX="17" dataY="140" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_13_0">Customer &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;:</span></div></div></div></div>\
      <div id="s-Text_14" class="pie label singleline firer ie-background commentable non-processed"   datasizewidth="99px" datasizeheight="30px" dataX="17" dataY="158" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_14_0">Pickup Address :</span></div></div></div></div>\
      <div id="s-Button_pod" class="pie button singleline firer click commentable non-processed"   datasizewidth="109px" datasizeheight="49px" dataX="7" dataY="568" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_pod_0">CHECKOUT</span></div></div></div></div>\
      <div id="s-Button_pod_1" class="pie button singleline firer click commentable non-processed"   datasizewidth="115px" datasizeheight="49px" dataX="240" dataY="568" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_pod_1_0">CANCEL</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_6" class="shapewrapper shapewrapper-s-Line_6 non-processed"   datasizewidth="318px" datasizeheight="2px" dataX="22" dataY="477" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_6" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_6" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 318 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="330px" datasizeheight="15px" dataX="17" dataY="491" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Note: If any descrepancy with the shipment please call Customer Service</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="251px" datasizeheight="15px" dataX="41" dataY="505" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0"> for ADJUSTMENT and wait for Updated Informations.</span></div></div></div></div>\
      <div id="s-Button_pod_2" class="pie button singleline firer click commentable non-processed"   datasizewidth="112px" datasizeheight="49px" dataX="122" dataY="568" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_pod_2_0">STANDBY</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;