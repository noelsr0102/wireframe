(function(window, undefined) {
  var dictionary = {
    "5baafd5b-4c4c-4b1f-84f9-909afe9ecb2d": "Standby_Screen",
    "33526f3c-a43b-4c49-a3bf-4bd3cdaf837e": "Checkout_Screen",
    "eb71d8d5-bcbd-45dd-b413-324312dac3eb": "pickupUpdate_Screen",
    "6bda7741-17b7-45ce-81a0-3a0e542a0dab": "Map_screen",
    "5dded9e3-1724-494b-a6a7-db8435586a39": "Reject_Reason_Screen",
    "7b4f713a-e953-4040-b6df-c5afade4bdda": "Edited_Checkout_Screen",
    "9bd4f8d8-ef6c-457e-af47-984986996b4c": "Pickup_Info_Standby_Screen",
    "9e0b249d-a0e8-44f1-aff8-fddce9b3ab95": "DEXUpdate_Screen",
    "af44408f-9bcc-465b-9119-db19ee1ef7fa": "pickup_Screen",
    "681e9126-e3b0-400e-a8df-a016e721d862": "Print_edited_Screen",
    "ae27051c-44d3-4c6c-bb3c-a8f87b04a1a2": "pickuprequest_Screen",
    "ebc29430-19f7-4647-886e-da20729b5ccd": "pickup2_Screen",
    "a8b5f2d8-6b49-4328-8d62-afcc2297ba2c": "pickupDone_Screen",
    "76b3ad9a-04d4-44e5-89dc-32f359fdad8a": "Update_Pickup_Info_Screen",
    "0651cc37-5f92-474c-b213-96bd3a741be3": "epod",
    "001886ad-e5d0-4268-a801-2876e86a7820": "DeliverUpdate_Screen",
    "60d62d3b-a1fe-4b92-bd61-35d82b491c49": "Print_Screen",
    "9c2c4717-05b6-4fb8-b511-d10019deebe8": "eDS_Screen",
    "b58f1d43-4a0a-4856-8a39-6165da4fdc1b": "Print_Successful_Screen",
    "32ca08f1-a3b5-489e-82d9-680d0d3ac070": "dispatch_Screen",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Login_Screen",
    "121babcf-5430-431a-9e7e-069a568f4ff0": "Map2_screen",
    "792f207f-a8e5-47d6-af24-04185330b0cb": "PickupRequestStandby_Screen",
    "56124299-16ed-4403-8ec1-f238aa7c99ea": "2pickupUpdate_Screen",
    "22277bad-a603-4325-ab7a-980c11b93e81": "PUXUpdate_Screen",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);